<div class="container text-center">
    <div class="container-fluid jumbotron">
    <?php foreach ($news as $new) {
        if($new->id == $id) {
               //print_r($new);
                echo "<h1  > ". $new->title ."</h1>";
                echo "<p class=text-info> " . $new->content . "</p>";
                echo "<p class=text-info> Published in :  " . $new->datePublication." </p>";
                echo "<p >" . $new->description . " </p>";
        }
    }
    ?>
    </div>
</div>
