<!--Formulário para editar news-->
<div class="container container-fluid jumbotron"
style="padding-top: 50px; padding-bottom: 50px">
    <h2>Add News</h2>
        <?php foreach ($news as $new) {
            if ($new->id == $id) {
        ?>
    <form action="<?php echo site_url('News/updateNews') ?>" method="post">
        <div class="form-group">
            <input type="hidden" name="id" value="<?php echo $new->id; ?>">
            <input type="hidden" name="idUser" value="<?php echo $new->idUser; ?>">
            <input type="hidden" name="date" value="<?php echo Date('Y-m-d H:i:s'); ?>">
            <input type="text" class="form-control" name="title" placeholder="Title" required="" value="<?php echo $new->title; ?>">
        </div>
        <div class=" dropdown form-group">
          <select class=" form-control" name ='state'>
              <option  value="<?php echo $new->idState ?>"><?php echo $new->description; ?> </option>
                <?php
                    }
                }
                ?>
              <?php foreach ($state as $stat) { ?>
              <option value="<?php echo $stat->id ?>"><?php echo $stat->description ?></option>
              <?php
            } ?>
        </select>
              <?php foreach ($news as $new) {
                    if ($new->id == $id) {
              ?>
       </div>
        <div class="form-group">
          <textarea id="editor1"  class="form-control" name="mensagem" required="" value="<?php echo $new->content; ?>">
          <?php echo $new->content; ?></textarea>
        </div>
        <div class="form-group">
        <label>Upload Image</label>
        <input type='file' name="postimage" size="50" >
        </div>
        <div class="form-group">
            <input type="submit" name="BSubmit" class="btn btn-danger pull-right" value="Save"/>
        </div>
        <?php
            }
        }
        ?>
    </form>
</div>
