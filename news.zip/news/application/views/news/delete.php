<?php
defined('BASEPATH') or exit('URL inválida.');
?>

<div class="container text-center">
    <div class="container-fluid jumbotron">
        <div class="">
            <div class="row">
                <div class="card p-4 text-center">
                    <h4><?php echo 'Id da news: ' . $news['id'] ?></h4>
                    <h4><?php echo 'Title: ' . ($news['title']); ?></h4>
                    <h4><?php echo 'Content: ' . ($news['content']); ?></h4>
                    <p>Are you sure you want to delete?</p>
                    <div class="pt-3 pb-3">
                        <a href="<?php echo site_url('News/index') ?>" class="btn btn-primary">Cancel</a>
                        <a href="<?php echo site_url('News/deleteNews/' . $news['id'] . '/true') ?>" class="btn btn-primary">Delete</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>