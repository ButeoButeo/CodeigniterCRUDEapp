
<?php defined('BASEPATH') or exit('URL not valid'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Sua Página</title>
</head>
<Body>
    <div class="container ">
        <table class="table table-striped table-hover text-center" id="minhaTabela">
        <thead>
        <tr>
            <th>Title</th>
            <th>Date</th>
            <th>Content</th>
            <th>State</th>
            <th></th>
            <th></th>
        </tr>
        </thead>
            <tbody>
                <?php
                foreach ($news as $new) {
                    if ($new->bDeleted != 1) {
                ?>
                    <td><?php echo $new->title ?></td>
                    <td><?php echo $new->datePublication ?></td>
                    <td><?php echo word_limiter($new->content, 10); ?><a href="<?php echo BASE_URL('News/showNews/')?><?php echo $new->id; ?> " ><small class="text-info">..Read more</small></a></td>
                    <td><?php echo $new->description ?></td>
                    <td><a href="<?php echo base_url('News/editarNews/'); ?><?php echo $new->id; ?>"><input class="btn btn-info" type="submit" value="Edit" ></a><span> <i class="fas fa-pen"></i> </span></td>
                    <td><a href="<?php echo base_url(); ?>News/deleteNews/<?php echo $new->id; ?>"> <input class="btn btn-danger" type="submit" value="Delete" ></a><span> <i class="far fa-trash-alt"></i> </span></td></tr>
                <?php
                    }
                }
                ?>
            </tbody>
        </table>
        <div class="btn-toolbar">
                <div class="btn-group">
                 <?php
                echo '<div class="">'. $this->pagination->create_links(). '</div>';
                ?>
                </div>
        </div>
        </div>




