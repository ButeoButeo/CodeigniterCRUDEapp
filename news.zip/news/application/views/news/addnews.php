<!--Formulário para adicionar nova news a lista de news-->
<div class="container container-fluid jumbotron" >
    <h2>Add News</h2>
    <form action="<?php echo site_url('News/createNews') ?>" method="post">
        <div class="form-group">
            <input type="hidden" name="date" value="<?php  echo Date('Y-m-d H:i:s'); ?>">
            <input type="text" class="form-control" name="title" placeholder="Title" required="" >
        </div>
        <div class=" dropdown form-group">
          <select class="form-control" name ='state' required placeholder="State" >
              <option value="" disabled selected hidden>Please Choose State...</option>
              <?php foreach ($news as $new) { ?>
              <option value="<?php echo $new->id ?>"><?php echo $new->description ?></option>
              <?php } ?>
        </select>
       </div>
        <div class="form-group">
          <textarea id="editor1" type="text" class="form-control" name="mensagem" placeholder="mensagem" required="" minlength="400" required>
          </textarea>
        </div>
        <div class="form-group">
        <label>Upload Image</label>
        <input type='file' name="postimage" size="50" >
        </div>
        <div class="form-group">
            <input type="submit" name="BSubmit" class="btn btn-danger pull-right" value="Save"/>
        </div>
    </form>
</div>
