
<div class="container">
    <div class="form-group">
        <form class="navbar-form navbar-left " role="search" action="<?php echo site_url('News/search?title=&date=&state=') ?>" method="GET">
            <div class="form-group">
                <input type="text" class="form-control" placeholder="Title" name="title" value="<?php echo $_GET['title'] ?>">
            </div>
            <div class="form-group">
                <input type="date" class="form-control" placeholder="Date" name="date" value="<?php echo $_GET['date'] ?>">
            </div>
            <div class=" dropdown form-group">
                <select class="form-control" name ='state'>
                   <option value=""><?php if ($_GET['state']==1) {
                                        echo 'Publish';
                                        }
                                        else if ($_GET['state'] == 2)
                                        {
                                        echo 'Unpublish';
                                        }
                                        else {echo 'Chose the State..';
                                        }
                                    ?> </option>
                   <option value="1">Publish</option>
                   <option value="2">Unpublish</option>
                </select>
            </div>
            <button type="submit" class="btn btn-default">Search    <span><i class="fas fa-search"></i> </span></button>
        </form>
        <form action="<?php echo site_url('News/createNews') ?>" method="post">
            <div class=" pull-right">
                    <input  type="submit" class="btn btn-success" value="Add News" ><span Class="m-2">   <i class="fas fa-plus-circle"></i></span>
            </div>
        </form>
    </div>
</div>


