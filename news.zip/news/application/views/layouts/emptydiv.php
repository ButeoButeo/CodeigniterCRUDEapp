
<?php
/**
 *
 */
defined('BASEPATH') or exit('URL not valid'); ?>
        <div class="container-fluid text-center ">
            <hr>
            <p> </p>
        </div>
    </body>
</html>
