
<nav class="navbar navbar-default ">
  <div class="container-fluid">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </button>
      <a class="navbar-brand" href="#"><span><i class="fas fa-candy-cane"></i></span> XrsNews</a>
    </div>

    <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
      <ul class="nav navbar-nav">
        <li class="active"><a href="<?php echo base_url('News/index?title=&date=&state=') ?>"
>News List  <span> <i class="fas fa-list-ul"></i> </span><span class="sr-only">(current)</span></a></li>
        <li><a href="#"></a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li><a href="#"><?php echo 'Hello '.$this->session->userdata('name') ?></a></li>
        <li><a href="<?php echo base_url('Users/logout') ?>
"><button type="submit" class="btn btn-warning">LOGOUT  <span>  <i class="fas fa-sign-out-alt"></i></span></button></a></li>

      </ul>
    </div>
  </div>
</nav>



