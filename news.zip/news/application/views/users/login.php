<?php defined('BASEPATH') OR exit('URL not valid'); ?>

<div class=" container jumbotron" >
    <div class="form-group  ">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
            <h3>Login</h3>
            <form action="<?php echo base_url('users/loginVerification') ?>" method="post">
                <br>
                <div class="form-group">
                    <input type="text" name="username" id="" class="form-control" placeholder="nome ou email" required>
                    <label for="">Username</label>
                </div>
                <br>
                <div class="form-group">
                    <input type="text" name="password" id="" class="form-control" placeholder="password" required>
                    <label for="">Password</label>
                </div>
                <br>
                <div>
                    <input type="submit" class="btn btn-lg btn-success pull-right " value="Login">
                </div>
            </form>
                <div>
                    <br>
                    <br>
                    <br>
                    <small id="helpId" class="text-muted pull-right"> Recover Pasword </small>
                </div>
            </div>
        </div>
    </div>
</div>



