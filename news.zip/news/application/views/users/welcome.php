<div class="container text-center">
    <div class="container-fluid jumbotron">
    <h1>welcome Admin!</h1>
    <p>You're now in admin land....</p>

    </div>
</div>