<?php

/**
 * htaccess file  in the application directory that stops  prevent fake http header requests
 */
defined('BASEPATH') OR exit('No direct script access allowed');

/**
 * Controlador que faz a gestão dos utilizadores da aplicação
 */
class Users extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *	http://example.com/index.php/welcome
     *	- or -
    * 		http://example.com/index.php/welcome/index
    *	- or -
    * Since this controller is set as the default controller in
    * config/routes.php, it's displayed at http://example.com/
    *
    * So any other public methods not prefixed with an underscore will
    * map to /index.php/welcome/<method_name>
    * @see https://codeigniter.com/user_guide/general/urls.html
    */
    public function index()
    {
        $this->load->view('layouts/emptydiv');
        $this->load->view('layouts/head');
        $this->load->view('users/login');
        $this->load->view('layouts/footer');
    }

    /**
     * Carrega os dados da view e verifica os dados de login na base de dados
     *
     * @return void
     */
    public function loginVerification()
    {
        $formdata = [
            'email' => $this->input->post('username'),
            'password' => md5($this->input->post('password'))
        ];

        $this->load->model('UsersModel');
        $result = $this->UsersModel->loginBdVerification($formdata);
        if ($result) {
            $userdata = array(
                'id' => $result->id,
                'name'  => $result->name,
                'email'  => $result->email,
            );
            $this->session->set_userdata($userdata);
            redirect('Users/welcome');

        } else {
            echo 'Atenção: Username ou Password incorrecta. Try again!';
        }
    }

    /**
     * Mensagem de welcome para area de administrador
     *
     * @return void
     */
    public function welcome()
    {
        $this->load->view('layouts/head');
        $this->load->view('navbar/navbar');
        $this->load->view('users/welcome');
        $this->load->view('layouts/footer');
    }

    /**
     * Faz logout, destroi os dados em session e redireciona para o users/index.
     *
     * @return void
     */
    public function logout()
    {
        $this->session->unset_userdata(['email', 'id', 'name']);
        $this->session->sess_destroy();
        $this->session->userdata('email');
        redirect('Users/index');
    }
}
