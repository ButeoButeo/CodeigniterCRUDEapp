<?php
/**
 * Htaccess file  in the application directory that stops
 * prevent fake http header requests
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Controlador que faz a gestão das news
 */
class News extends CI_Controller
{
    /**
     * Construtor da class News. Classe que gere as notícias
     */
    public function __construct()
    {
        parent::__construct();
        $this->load->model('NewsModel');
    }

    /**
     * Index Page for this controller. Carrega a lista de notícias,
     * que estão como não apagadas (bDeleted=0), se o utilizador fez login, e faz a paginação
     *
     * Maps to the following URL
     *	http://example.com/index.php/welcome
     *	- or -
     * 		http://example.com/index.php/welcome/index
     *	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function index()
    {
        if (!empty($this->session->userdata('email'))) {

            $option['base_url'] = base_url('/News/index');
            $config["first_url"] = site_url('/News/index')
            . (!empty($this->input->get()) ? '?'
            . http_build_query($this->input->get()) : '' ) ;
            $option['total_rows'] = $this->db->get('news')->num_rows();
            $offset = $this->uri->segment(3);
            $this->pagination->initialize($option);
            $data['news'] = $this->NewsModel->getDbNewsPagination(10, $offset);
            $this->load->view('layouts/head');
            $this->load->view('navbar/navbar');
            $this->load->view('layouts/emptydiv');
            $this->load->view('news/filter');
            $this->load->view('layouts/emptydiv');
            $this->load->view('news/list', $data);
            $this->load->view('layouts/footer');
        } else {
            echo 'Please, Login!';
        }
    }

    /**
     * Adiciona nova noticia. faz o form validation dos inputs da view addnews. Se o utilizador ter feito login e existirem dados na session
     *
     * @return void
     */
    public function createNews()
    {
        if (!empty($this->session->userdata('email'))) {
            $data = array();
            $userData = array();
            if ($this->input->post('BSubmit')) {
                $this->form_validation->set_rules('title', 'title', 'required');
                $this->form_validation->set_rules('state', 'state', 'required');
                $this->form_validation->set_rules('mensagem', 'mensagem', 'required');

                $newsdata = array(
                    'title' => $this->input->post('title'),
                    'datePublication' => $this->input->post('date'),
                    'idState' => $this->input->post('state'),
                    'content' => $this->input->post('mensagem'),
                    'idUser' => $this->session->userdata('id'),
                    'bDeleted' => 0
                );
                if ($this->form_validation->run() == true) {
                    $this->load->model('NewsModel');

                    $config['upload_path'] = './assets/imgs';
                    $config['allowed_type'] = 'gif|jpg|png';
                    $config['max_size'] = '2048';
                    $config['upload_path'] = './assets/imgs';

                    $insert = $this->NewsModel->createDbNews($newsdata);
                    if ($insert) {
                        redirect('News/index?title=&date=&state=');
                    }
                }
            }
            $dados['news'] = $this->NewsModel->getDbstate();
            $this->load->view('layouts/head');
            $this->load->view('navbar/navbar');
            $this->load->view('news/addnews', $dados);
            $this->load->view('layouts/footer');
        }
    }

    /**
     * Carrega a view com os dados da noticia a editar
     *
     * @return void
     */
    public function editarNews()
    {
        if (!empty($this->session->userdata('email'))) {
            $data['id'] = $this->uri->segment(3);
            $data['news'] = $this->NewsModel->getDbNews();
            $data['titulo'] = 'XrsNews';
            $data['state'] = $this->NewsModel->getDbstate();
            $this->load->view('layouts/head', $data);
            $this->load->view('navbar/navbar');
            $this->load->view('news/editnews', $data);
            $this->load->view('layouts/footer');
        }
    }

    /**
     * Actualiza a noticia editada na base de dados
     *
     * @return void
     */
    public function updateNews()
    {
        if (!empty($this->session->userdata('email'))) {
            $data = array(
            'title' => $this->input->post('title'),
            'idState' => $this->input->post('state'),
            'content' => $this->input->post('mensagem'),
            'idUser' => $this->input->post('idUser'),
            'id' => $this->input->post('id'),
            'datePublication' => $this->input->post('date')
            );
            $this->NewsModel->updateDbNews($data);
            redirect('News/index?title=&date=&state=');
        }
    }

    /**
     * Apaga a noticia da lista apresentada mas não da base de dados.
     * Na base de dados actualiza o estado bDeleted.
     *
     * @param [type] $id
     * @param boolean $resposta
     * @return void
     */
    public function deleteNews($id, $resposta = false)
    {
        if (!empty($this->session->userdata('email'))) {
            if (!$resposta) {
                $dados['news'] = $this->NewsModel->newsId($id)[0];
                $this->load->view('layouts/head');
                $this->load->view('navbar/navbar');
                $this->load->view('news/delete', $dados);
                $this->load->view('layouts/footer');
            } else {
                //$this->NewsModel->deleteDbNews($id);
                $bdeleted = array(
                    'bDeleted' => 1,
                    'id' => $id
                );
                $this->NewsModel->updatebDeleted($bdeleted);
                redirect('News/index?title=&date=&state=');
            }
        }
    }

    /**
     * Gere a pesquisa das notícias por título,
     * estado e data da publicação
     *
     * @return void
     */
    public function search()
    {
        if (!empty($this->session->userdata('email'))) {
            $dados = array(
                'title' => $this->input->get('title'),
                'news.idState' => $this->input->get('state'),
                'datePublication' => $this->input->get('date'),
            );
            $option['base_url'] = base_url('/News/search');

            $option['total_rows'] = $this->db->get('news')->num_rows();
            $option['per_page'] = 10;
            $limit = $option['per_page'];
            ($this->uri->segment(3)!='') ? $offset =$this->uri->segment(3): $offset =0;
            $this->pagination->initialize($option);
            $data['news'] = $this->NewsModel->searchDb($dados, $limit, $offset);
            $this->load->view('layouts/head');
            $this->load->view('navbar/navbar');
            $this->load->view('layouts/emptydiv');
            $this->load->view('news/filter');
            $this->load->view('layouts/emptydiv');
            $this->load->view('news/list', $data);
            $this->load->view('layouts/footer');
        }
    }

    /**
     * mostra a notícia completa ao clicar no read more..
     *
     * @return void
     */
    public function showNews() {
        if (!empty($this->session->userdata('email'))) {
            $data['id'] = $this->uri->segment(3);
            $data['news'] = $this->NewsModel->getDbNews();
            $this->load->view('layouts/head');
            $this->load->view('navbar/navbar');
            $this->load->view('news/show', $data);
            $this->load->view('layouts/footer');
        }

    }

}
