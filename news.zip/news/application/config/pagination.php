<?php
defined('BASEPATH') or exit('No direct script access allowed');

$config["use_page_numbers"] = false;
$config["reuse_query_string"] = true;



$config['num_links'] = 3;
//$config['uri_segment'] = 3;


$config['first_link'] = 'false';
$config['first_tag_open'] = '<div class="btn-group">';
$config['first_tag_close'] = '</div>';

$config['full_tag_open'] = "<ul class='pagination'>";
$config['full_tag_close'] = '</ul>';
$config['num_tag_open'] = '<li>';
$config['num_tag_close'] = '</li>';
$config['cur_tag_open'] = '<li class="active"><a href="#">';
$config['cur_tag_close'] = '</a></li>';
$config['prev_tag_open'] = '<li>';
$config['prev_tag_close'] = '</li>';
$config['first_tag_open'] = '<li>';
$config['first_tag_close'] = '</li>';
$config['last_tag_open'] = '<li>';
$config['last_tag_close'] = '</li>';

$config['next_link'] = 'Next Page';
$config['next_tag_open'] = '<li><i class="fa fa-long-arrow-right"></i>';
$config['next_tag_close'] = '</li>';

$config['prev_link'] = 'Previous Page';
$config['prev_tag_open'] = '<li><i class="fa fa-long-arrow-left"></i>';
$config['prev_tag_close'] = '</li>';


$config["last_link"] = 'false';