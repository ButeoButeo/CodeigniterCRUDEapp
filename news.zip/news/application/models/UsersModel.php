<?php

/**
 * htaccess file  in the application directory that stops
 * prevent fake http header requests
 */
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Model que acede aos dados dos utilizadores na base de dados
 */
class UsersModel extends CI_Model
{

    /**
     * verifica dados de login na base de dados e coloca o nome,
     *  email e password na session
     *
     * @param [type] $formdata
     * @return boolean
     */
    public function loginBdVerification($formdata)
    {
        $this->db->select('id, name, email, password');
        $this->db->from('user');
        $this->db->where('email', $formdata['email']);
        $this->db->where('password', $formdata['password']);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {

            return $query->row();
        } else {
            return false;
        }
    }




}
