<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 * Controlador que gere o read, create, update, delete and search das notícias.
 */
class NewsModel extends CI_Model
{

    /**
     * Lê os dados das notícias da base de dados e envia para o controlador News, que envia para a view news/list
     *
     * @return void
     */
    public function getDbNews()
    {
        $this->db->select('news.title, news.bDeleted, news.datePublication, state.id, news.id, news.idUser, news.content, news.idState, state.description');
        $this->db->from('news');
        $this->db->join('state' ,'news.idState = state.id');
        return $this->db->get()->result();
    }

    /**
     * Lê os dados das notícias da base de dados e envia para o controlador News, que envia para a view news/list, com limit e offset para paginação
     *
     * @param [type] $limit
     * @param [type] $offset
     * @return void
     */
    public function getDbNewsPagination($limit = null, $offset = null)
    {
        $this->db->select('news.title, news.bDeleted, news.datePublication, state.id, news.id, news.idUser, news.content, news.idState, state.description');
        //$this->db->from('news');
        $this->db->where('news.bDeleted', 0);
        $this->db->join('state', 'news.idState = state.id');
        return $this->db->get('news', $limit, $offset)->result();
    }

    /**
     * insere a nova news na base de dados
     *
     * @param array $newsdata
     * @return void
     */
    public function createDbNews($newsdata = array())
    {
        $insert = $this->db->insert('news', $newsdata);
        if ($insert) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Retorna os dados do produto
     *
     * @param [type] $id
     * @return void
     */
    public function newsid($id)
    {
        return $this->db->from('news')->where('id', $id)->get()->result_array();
    }

    /**
     * Actualiza news editada na base de dados, no mesmo id
     *
     * @return void
     */
    public function updateDbNews($data)
    {
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('news', $data);
    }

    /**
     * Faz o delete da news selecionada, na base de dados
     *
     * @param [type] $id
     * @return void
     */
    public function updatebDeleted($bdeleted)
    {
       // $this->db->delete('news', array('id' => $id));
        $this->db->where('id', $bdeleted['id']);
        $this->db->update('news', $bdeleted);
    }


    /**
     * Pesquisa as news na base de dados
     *
     * @param [type] $dados
     * @return void
     */
    public function searchDb($dados, $limit = null, $offset = null)
    {

        $this->db->select("news.title, news.datePublication, state.id, news.id, news.idUser, news.content, news.idState, state.description, news.bDeleted ");
        $this->db->from("news");
        $this->db->join('state', 'news.idState = state.id');
        $this->db->where('news.bDeleted', 0);
        $this->db->like('SUBSTRING(datePublication,1,10)', $dados['datePublication']);
        $this->db->like('news.idState', $dados['news.idState']);
        $this->db->like('title', $dados['title']);
        if ($limit >0) {
                $this->db->limit($limit, $offset);
        }
        return $this->db->get()->result() ?? null;

    }

    /**
     * Lê dados da tabela state na DB
     *
     * @return void
     */
    public function getDbstate()
    {
        $this->db->select('id, description');
        $this->db->from('state');
        return $this->db->get()->result();
    }


}
